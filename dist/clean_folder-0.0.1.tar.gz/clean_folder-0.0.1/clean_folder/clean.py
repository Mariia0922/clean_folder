def cleaning():
    print()
